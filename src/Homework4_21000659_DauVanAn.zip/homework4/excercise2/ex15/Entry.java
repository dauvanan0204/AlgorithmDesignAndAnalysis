package homework4.excercise2.ex15;
public interface Entry<K, E> {
    K getKey();
    E getValue();
}
